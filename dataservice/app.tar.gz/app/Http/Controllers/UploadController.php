<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-3
 * Time: 下午11:46
 */

namespace App\Http\Controllers;


class UploadController extends Controller
{

}