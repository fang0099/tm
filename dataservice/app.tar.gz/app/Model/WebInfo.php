<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-1
 * Time: 下午10:34
 */

namespace App\Model;

class WebInfo extends BaseModel
{
    protected $table = 'web_info';


}