<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-7
 * Time: 下午1:19
 */

namespace App\Model;


class CheckLog extends BaseModel
{
    protected $table = 'check_log';
}