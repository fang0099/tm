<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-3
 * Time: 下午2:07
 */

namespace App\Model;


class Functions extends BaseModel
{
    protected $table = 'functions';
}