<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-6
 * Time: 下午9:46
 */

namespace App\Model;



class NewsFlash extends BaseModel
{
    protected $table = 'news_flash';
}