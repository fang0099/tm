<?php
/**
 * Created by PhpStorm.
 * User: bean
 * Date: 16-12-6
 * Time: 下午10:08
 */

namespace App\Model;


class Sponsors extends BaseModel
{
    protected $table = 'sponsors';
}